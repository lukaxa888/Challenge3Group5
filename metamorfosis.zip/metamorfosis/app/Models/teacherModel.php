<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class teacherModel extends Model
{
    use HasFactory;
    protected $fillable = [
        'name',
        'dni',
        'surname1',
        'surname2',
        'age',
        'userName',
        'password',
        'type'
    ];

    public function classes(){
        return $this->hasMany('\App\Models\Clases');

        
    }
}
