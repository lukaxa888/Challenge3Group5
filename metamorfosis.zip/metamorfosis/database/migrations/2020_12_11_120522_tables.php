<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Tables extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('admin', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name');
            $table->string('dni');
            $table->string('surname1');
            $table->string('surname2');
            $table->integer('age');
            $table->string('userName');
            $table->password('password');
            $table->softDeletes();
            $table->timestamps();
        });
        Schema::create('user', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name');
            $table->string('dni');
            $table->string('surname1');
            $table->string('surname2');
            $table->integer('age');
            $table->string('userName');
            $table->password('password');
            $table->integer('tariff');
            $table->softDeletes();
            $table->timestamps();
        });
        Schema::create('teacher', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name');
            $table->string('dni');
            $table->string('surname1');
            $table->string('surname2');
            $table->integer('age');
            $table->string('userName');
            $table->password('password');
            $table->integer('type');
            $table->softDeletes();
            $table->timestamps();
        });
        Schema::create('class', function (Blueprint $table) {
            $table->increments('id');
            $table->date('date');
            $table->integer('duration');
            $table->integer('type');
            $table->foreignId('teacher_id')->constrained();
            $table->softDeletes();
            $table->timestamps();
        });



    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
