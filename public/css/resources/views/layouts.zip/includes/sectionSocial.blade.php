
<!-- 
    SECTION DONDE SE METE LA PARTE DE SOCIAL E IMAGENES DE PAGO
    <section id="socialMe">
-->


  <div id="footerBox1">
  <h1>{{ trans('messages.subscribe') }}</h1>
  <h2>{{ trans('messages.email1') }}</h2> <input type="text" name="Gmail" placeholder="{{ trans('messages.subscribeph') }}">
  <p></p>
  <input type="checkbox" id="cbox2" value="second_checkbox"> <label for="cbox2">{{ trans('messages.read') }}</label>
  <p></p>
  <input type="submit" name="send" value="{{ trans('messages.send') }}">
  </div>
  <div id="footerBox2">
    <img class="socialLinkImages" src="img/instagram.jpg">
    <img class="socialLinkImages" src="img/twitter.png">
    <img class="socialLinkImages" src="img/facebook.png">
    
  </div>
  <div id="footerBox3">
    <img src="img/payment.jpg">
  </div>
  <div id="footerBox4">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2903.5847447575666!2d-1.9908732845135921!3d43.30201717913491!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd51b01d51947163%3A0x8916ad3db217f11e!2sEtxadi%20kiroldegia!5e0!3m2!1ses!2ses!4v1606982351093!5m2!1ses!2ses" width="200" height="200" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
  </div>
