<!--   
    ESTO ES LO QUE TIENE QUE TNER EL NAV DE AJAX
    <nav id="navNoticias" class="bg-primary">
-->
  <p>{{ trans('messages.news') }}</p>
